<div id="update_content" class="container">
	<div class="row">
		<div class="col-md-offset-2 col-md-8 col-md-offset-2">
			<h2>Formulaire de mis à jour des infos d'un article</h2><hr>
			<form method="POST" action="index.php" class="form-horizontal">
				<div class="form-group">
					<h3><label class="control-label col-md-2" for="article">Article: </label></h3>
					<div class="col-md-10">
  						<input type="text" class="form-control" id="article" name="newArticle" value="<?php echo $_GET['article'] ?>">
					</div>
				</div>
				<div class="form-group">
					<h3><label class="control-label col-md-2" for="article">Montant: </label></h3>
					<div class="col-md-10">
  						<input type="number" class="form-control" id="article" name="newMontant" value="<?php echo $_GET['montant'] ?>">
					</div>
				</div>
					<input type="submit" name="update" value="Modifier" class="btn btn-primary">
			</form>
			<a href="../../index.php" class="retour_sur_home"><h4>Retourner sur la page d'accueil</h4></a>
		</div>
	</div>
</div>