<?php

//Inserting of update file
include_once('view/home_items/update.php');