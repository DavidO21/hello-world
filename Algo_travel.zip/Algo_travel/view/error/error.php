<!DOCTYPE html>
<html>
	<head>
		<?php include ('partials/head.php')  ?>
	</head>
	<body>
		<?php include ('partials/header.php')  ?>
		<main>
			<?php include ('partials/error_content.php')  ?>
		</main>	
		<script type="text/javascript" src="../js/jquery-2.2.3.min.js"></script>
		<script type="text/javascript" src="../js/index.js"></script>
	</body>
</html>