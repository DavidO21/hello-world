<?php 

//Variable of definition of my controller
$_SESSION['manage'] = 'management';

//Inserting of connexion
include_once('model/connexion.php');

//Creating of Necessity object
// class Necess{

// 	//privatre variable

// 	public function __construct(){

// 	}
// }