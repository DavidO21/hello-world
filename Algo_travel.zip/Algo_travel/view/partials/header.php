<header>
	<nav>
	  	<div class="container-fluid">
	    	<div class="navbar-header">
	      		<a class="navbar-brand" href="index.php">Cash_Management</a>
	    	</div>
	    	<ul class="nav navbar-nav" id="link">
			     <li class="active"><a href="index.php">Home_items</a></li>
			     <li><a href="management.php">Management</a></li>
	    	</ul>
	  	</div>
	</nav>
</header>