<div id="content" class="container">
	<div class="row">
		<div class="col-md-5" id="form_left">
			<h2>Formulaire de renseignement des articles</h2><hr>
			<form method="POST" action="/">
				<div class="form-inline couple_champ">
					<input type="text" class="form-control" name="article" placeholder="Article1" />
					<input type="number" class="form-control" name="montant" placeholder="Montant correspondant" />
				</div>
				<div class="form-inline couple_champ" id="btn">
					<input type="reset" class="btn btn-warning" name="cancel" value="Annuler" />
					<input type="submit" class="btn btn-success" name="cancel" value="Valider" />
				</div>
			</form>
		</div>
		<div class="col-md-7" id="form_right">
			<h2>Vue sur tout les articles avec leurs montants correspondants</h2><hr>
			<?php foreach($items as $data){ ?>
			<h3 id="article"> 
				<?php echo $data['Item']; ?> : <span class="amount"> <?php echo $data['Montant']; ?> </span><sup>fcfa</sup><span>
				<a href="/?idArticle=<?php echo $data['Id']; ?>">
					<input type="button" class="btn btn-danger" value="Supprmer" />
				</a>
				<a href="update.php?idArticle=<?php echo $data['Id'] ?>&amp;article=<?php echo $data['Item'] ?>&amp;montant=<?php echo $data['Montant'] ?> ">
					<input type="button" class="btn btn-primary" value="Modifier" />
				</a></span>
			</h3>
			<?php } ?>
			<div id="account">
				<h2>Total : <span id="total"></span></h2>
			</div>
		</div>
	</div>
</div>