<meta charset="utf-8" />
<title>Algo_travel</title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
<link rel="stylesheet" href="assets/css/index.css" />