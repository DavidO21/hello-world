<?php

//Session starting
session_start();

//Inserting of model file
require('model/management/model.php');

//Inserting of controller file after condition
if ( isset($_SESSION['manage']) AND $_SESSION['manage']== 'management') {
	
	include_once('controller/management/controller.php');
}

else{
	include_once('view/error/error.php');
}