$(function(){

	//Variables
	var amount = $('.amount'),
		total = $('#total'),
		id= 0,
		id+=1;

	//
	if (amount.innerHTML != null) {

		console.log('null');
	}else{
		//
		var i = amount.length;
			amount.attr('class', id++);
			
		var account ;
		console.log(i);
	}

});