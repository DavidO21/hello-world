<div id="content" class="container">
	<div class="row">
		<div class="col-md-5">
			<div id="bordure">
				<h3>Management formulaire</h3>
				<div class="row">
					<div class="col-md-12">
						<input type="number" class="form-control initialAmount" placeholder="Entrez le montant initial">
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<input type="text" disabled="disabled" value="Loyer" class="form-control nOne">
					</div>
					<div class="col-md-6">
						<input type="number" class="form-control aOne">
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<input type="text" disabled="disabled" value="Electricité" class="form-control nTwo">
					</div>
					<div class="col-md-6">
						<input type="number" class="form-control aTwo">
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<input type="text" disabled="disabled" value="Transport" class="form-control nThree">
					</div>
					<div class="col-md-6">
						<input type="number" class="form-control aThree">
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<input type="text" disabled="disabled" value="Manger" class="form-control nFour">
					</div>
					<div class="col-md-6">
						<input type="number" class="form-control aFour">
					</div>
					<button class="btn btn-default pull-right calculate">Calcul puis affiche</button>
				</div>
				<div id="errorSentence"></div>
			</div>
		</div>
		<div class="col-md-7">
			<table class="table table-bordered">
				<thead>
					<tr>
						<td>Nécessité</td>
						<td>Montant</td>
						<td>Actions</td>
					</tr>
				</thead>
				<tbody id="tbodyNecess">
				</tbody>
			</table>
			<p id="btn"></p>
		</div>
	</div>
	<div id="bloc_table">
		<table class="table table-bordered">
			<thead>
				<tr>
					<td>Id</td>
					<td>Necessité</td>
					<td>Montant</td>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>01</td>
					<td>Loyer</td>
					<td>35.000<sup>fcfa</sup></td>
				</tr>
				<tr>
					<td colspan="3">
						<div id="infos_necessite">
							<h4>Date de sauvegarde : <b>15/05/2017 A 15h05</b></h4>
							<h4>Total: <b>100.000<sup>fcfa</sup></b></h4>
							<h4>Reste: <b>10.000<sup>fcfa</sup></b></h4>
							<h4 class="pull-right">
								<button class="btn btn-primary">Modifier</button> 
								<button class="btn btn-danger">Supprimer</button> 
							</h4>
						</div>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>	