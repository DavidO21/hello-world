<?php

//Definition of collection variable
$_SESSION['index'] = 'home_items';

//Inserting of connexion file
include_once('model/connexion.php');

//Creating of object request
class Articles {
	
	//private Variables 
	private $results;

	public function __construct(){
	}

	public function setArticle($article, $montant){
		
		//Insert data
		global $bdd;
		$insert = $bdd->prepare('INSERT INTO items (Id, Item, Montant) VALUES (null, :article, :montant)');
		$insert->execute([
			'article' => $article,
			'montant' => $montant
		]);
	}

	//Function of data reception
	public function getArticle(){
		
		//Query to bdd
		global $bdd;
		$req = $bdd->query('SELECT * FROM items');

		$res = $req->fetchAll();
		
		//Return $result for using in controller home_items
		$this->results = $res;
		
		return $this->results;

		//Closing of query or request
		$req->closeCursor();
		
	}

	public function updateArticle($idArticle, $newArticle, $newMontant){

		global $bdd;
		$up = $bdd->prepare("UPDATE items SET Item = :article, Montant = :montant WHERE Id = :id");
		$up->execute([
			'article' => $newArticle,
			'montant' => $newMontant,
			'id' => $idArticle
		]); 
	}

	public function deleteArtcle($id){

		//Deleting action to database
		global $bdd;
		$del = $bdd->prepare("DELETE FROM items WHERE Id =:identifiant");

		$del->execute([
			'identifiant' => $id
		]);
	}	
}