<!DOCTYPE html>
<html>
	<head>
		<?php include ('view/partials/head.php')  ?>
	</head>
	<body>
		<?php include ('view/partials/header.php')  ?>
		<main>
			<?php include ('partials/index_content.php')  ?>
		</main>	
		<script type="text/javascript" src="assets/js/jquery-2.2.3.min.js"></script>
		<script type="text/javascript" src="assets/js/item.js"></script>
	</body>
</html>