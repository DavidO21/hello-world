<?php 
//Session starting
session_start();

require('model/home_items/model.php');

//Starting of my app
if ( $_SESSION['index']=='home_items' ){
	
	//Insert index file of home items
	include_once('controller/home_items/controller.php');
}
else{
	include_once('view/error/error.php');
}

