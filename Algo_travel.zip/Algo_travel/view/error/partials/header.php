<header>
	<nav>
	  	<div class="container-fluid">
	    	<div class="navbar-header">
	      		<a class="navbar-brand" href="#">Cash_Management</a>
	    	</div>
	    	<ul class="nav navbar-nav" id="link">
			     <li class="active"><a href="/">Home items</a></li>
			     <li><a href="view/management/index.php">management by month</a></li>
	    	</ul>
	  	</div>
	</nav>
</header>