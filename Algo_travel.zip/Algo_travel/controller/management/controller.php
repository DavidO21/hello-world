<?php 

//Insedatating of model file
include_once('model/management/model.php');

//Duplication of my object
//$necess = new Necess();

//Ajax
if (isset($_GET['donnees']) && empty($_GET['donnees'])) {
	
	$data = $_GET['donnees'];
	echo $data;
}



//Including of my index file
include_once('view/management/index.php');

