$(function(){

	//Variables useful
	var aInitial = $('.initialAmount'),
	nOne = $('.nOne'),
	nTwo = $('.nTwo'),
	nThree = $('.nThree'),
	nFour = $('.nFour'),
	aOne = $('.aOne'),
	aTwo = $('.aTwo'),
	aThree = $('.aThree'),
	aFour = $('.aFour'),
	tbody = $('#tbodyNecess'),
	account,
	calculation,
	rest;

		
			//aInitial
		aInitial.on('blur', ()=>{
			if (aInitial.val()=='') 
			{
				aInitial.css('border','1pt solid #c50101');
				//
				firstB = false;
			 }
			 else{

				aInitial.css('border', '1pt solid #26a000');

				firstB = true;
			} 
		});
			//aOne
		aOne.on('blur', ()=>{
			if(aOne.val()=='')
			{
				aOne.css('border','1pt solid #c50101');
				//
				secondB = false;

			}else{
				
				aOne.css('border', '1pt solid #26a000');
				secondB = true;
			}
		});
			//aTwo
		aTwo.on('blur', ()=>{
			if(aTwo.val()=='')
			{
				aTwo.css('border','1pt solid #c50101');
				//
				thirdB = false;

			}else{
				
				aTwo.css('border', '1pt solid #26a000');
				thirdB = true;
			}
		});
			//aThree
		aThree.on('blur', ()=>{
			if(aThree.val()=='')
			{
				aThree.css('border','1pt solid #c50101');
				//
				fourthB = false;

			}else{
				
				aThree.css('border', '1pt solid #26a000');
				fourthB = true;
			}
		});
			//aFour
		aFour.on('blur', ()=>{
			if(aFour.val()=='')
			{
				aFour.css('border','1pt solid #c50101');
				//
				fivethB = false;

			}else{
				
				aFour.css('border', '1pt solid #26a000');
				fivethB = true;
			}
		});
	
	
	//Creation of an object for adding
	function Calculation(amount1, amount2, amount3, amount4){

		//Constructor
		this.amount1 = amount1;
		this.amount2 = amount2;
		this.amount3 = amount3;
		this.amount4 = amount4;

		//Creation of calculate method
		this.calculate = (amount1, amount2, amount3, amount4)=>{
			//Calculation
			result = parseInt(this.amount1) + parseInt(this.amount2) + parseInt(this.amount3) + parseInt(this.amount4);
			return result;
		}
	}

	//Creation of makeCalculation function
	function calcAndDisplay(){
		
		//Amounts values table
		var montant = [aOne.val(), aTwo.val(), aThree.val(), aFour.val()];
		
		var buttons = "class='btn btn-warning glyphicon glyphicon-pencil'>" + "<a class='btn btn-danger glyphicon glyphicon-trash'";

		var loyer = $('<tr><td id="first">' + 'Loyer' + '</td>' + '<td><b>' + montant[0] + '</b><sup>fcfa</sup></td><td id="btnAction"><a id="lM"' + buttons +' id="lS"' + '></td></tr>');
		//Displaying of informations to table

		var electricite = $('<tr><td id="second">' + 'Electricite' + '</td>' +  '<td><b>' + montant[1] + '</b><sup>fcfa</sup></td><td id="btnAction"><a id="eM"' + buttons +' id="eS"' + '></td></tr>');

		var transport = $('<tr><td id="third">' + 'Transport' + '</td>' + '<td><b>' + montant[2] + '</b><sup>fcfa</sup></td><td id="btnAction"><a id="tM"' + buttons +' id="tS"' + '></td></tr>');
		
		var manger = $('<tr><td id="fourth">' + 'Manger' + '</td>' + '<td><b>' + montant[3] + '</b><sup>fcfa</sup></td><td id="btnAction"><a id="nM"' + buttons +' id="nS"' + '></td></tr>');

		var btnSave  = $('<button class="btn btn-success pull-right mg" title="Enregistrer ces données dans la base de donnée">Sauvegarder</button>');
		var btnCancel = $('<button id="btnCancel" class="btn btn-danger pull-right" title="Réinitialiser ce tableau pour en génerer un autre à partir du formulaire">Réinitialiser</button>');

		//Inserting in the DOM of first tr 
		tbody.append(loyer);
		tbody.append(electricite);
		tbody.append(transport);
		tbody.append(manger);

		//Script of calcul
		calculation = new Calculation($('.aOne').val(), $('.aTwo').val(), $('.aThree').val(), $('.aFour').val());
		
		//Total
		account = calculation.calculate();
		
		//Reste
		rest = parseInt(aInitial.val() - account) ;

		var total ='<p>Total: ' + '<b id="total">' + account + '</b><sup>fcfa</sup></p>';

		var reste ='<p>Reste: ' + '<b id="rest">' + rest + '</b><sup>fcfa</sup></p>';

		var initial ='<p id="mI">Montant initail: ' + '<b id="initAmount">' + aInitial.val() + '</b><sup>fcfa</sup></p>';
		
		var rapport = $('<tr><td colspan="3" id="rapport"><div>' + initial + total + reste + '</div></td></tr>');
		
		//Caling of update and delete functions
		updateBtn();
		deleteBtn();
		
		tbody.append(rapport);

		//Inserting of save btn
		$('#btn').append(btnSave);
		$('#btn').append(btnCancel);

		//Function cancel btn
		cancelAction();

		//Function save btn
		saveAction();
	}

	//After click event on calculateBtnw	
	$('.calculate').on('click', ()=>{
		
		if (firstB==false || secondB==false || thirdB==false || fourthB==false || fivethB==false || aInitial.val()=='') 
			{
				//Alert
				sweetAlert("Champ(s) vide(s)", "Attention!! Veuillez prendre le soin de remplir tous les champs, car cela est très important pour la suite.", "error");
				
			}
		else{	

				//Checking of existing of table in the page
				if ($('#mI b').text() != $('.initialAmount').val()) 
				{
					//Alert
					swal("Opérations effectuées avec succès!", "" ,"success");

					//Calling of my treatment function
					calcAndDisplay();

				}else
				{
					//ALert
					sweetAlert("Attention!!", "Veillez reinitialiser en premier le tableau présent avant de réaliser cette action.", "error");
				
				}
					
			}
	});



	//=======================After creating of the table====================

	//Creating of updateBtn function and useful variables
	var truth = true,
	newCalc,
	newAccount,
	newRest;

	function updateBtn(){
		//Loyer
		$('#lM').on('click', ()=>{

			if (truth) {
				
			//Loyer, style btn et montant correspondant
				$('#lM').removeClass('btn-warning glyphicon-pencil').addClass('btn-success glyphicon-share');
				$('#first').html('<input id="newFirstNecess" type="text" class="form-control" value="'+ $('#first').text() +'"/>');
				$('#first+td b').html('<input id="newFirstAmount" type="number" class="form-control" value="'+ $('#first+td b').text() +'"/>');
			
				//Changing of truth value
				truth = false;
			}
			else{

				//Loyer, montant et btn nouvelle value
				$('#lM').removeClass('btn-success glyphicon-share').addClass('btn-warning glyphicon-pencil');
				$('#first').html($('#newFirstNecess').val());
				$('#first+td b').html($('#newFirstAmount').val());

				//After modifying of amount
				newCalc = new Calculation($('#first+td b').text(), $('#second+td b').text(), $('#third+td b').text(),$('#fourth+td b').text());
				newAccount = newCalc.calculate();
				newRest = aInitial.val() - newAccount;
				$('#total b').html(newAccount);
				$('#rest b').html(newRest);
				
				//Changing of truth value
				truth = true;
			}
		});	

		//Elec
		$('#eM').on('click', ()=>{
			if (truth) {

				//Electricité, style btn et montant correspondant
				$('#eM').removeClass('btn-warning glyphicon-pencil').addClass('btn-success glyphicon-share');
				$('#second').html('<input id="newSecondNecess" type="text" class="form-control" value="'+ $('#second').text() +'"/>');
				$('#second+td b').html('<input id="newSecondAmount" type="number" class="form-control" value="'+ $('#second+td b').text() +'"/>');

				truth = false;
			}
			else{
				//Electricité et montant nouvelle value
				$('#eM').removeClass('btn-success glyphicon-share').addClass('btn-warning glyphicon-pencil');
				$('#second').html($('#newSecondNecess').val());
				$('#second+td b').html($('#newSecondAmount').val());

				//After modifying of amount
				newCalc = new Calculation($('#first+td b').text(), $('#second+td b').text(), $('#third+td b').text(),$('#fourth+td b').text());
				newAccount = newCalc.calculate();
				newRest = aInitial.val() - newAccount;
				$('#total b').html(newAccount);
				$('#rest b').html(newRest);
				
				truth = true;
			}
		});

		//Trans
		$('#tM').on('click', ()=>{
			if (truth) {

				//Transport, style btn et montant correspondant
				$('#tM').removeClass('btn-warning glyphicon-pencil').addClass('btn-success glyphicon-share');
				$('#third').html('<input id="newThirdNecess" type="text" class="form-control" value="'+ $('#third').text() +'"/>');
				$('#third+td b').html('<input id="newThirdAmount" type="number" class="form-control" value="'+ $('#third+td b').text() +'"/>');

				truth = false;
			}
			else{
				//Transport et montant nouvelle value
				$('#tM').removeClass('btn-success glyphicon-share').addClass('btn-warning glyphicon-pencil');
				$('#third').html($('#newThirdNecess').val());
				$('#third+td b').html($('#newThirdAmount').val());


				//After modifying of amount
				newCalc = new Calculation($('#first+td b').text(), $('#second+td b').text(), $('#third+td b').text(),$('#fourth+td b').text());
				newAccount = newCalc.calculate();
				newRest = aInitial.val() - newAccount;
				$('#total b').html(newAccount);
				$('#rest b').html(newRest);

				truth = true;
			}
		});

		//New
		$('#nM').on('click', ()=>{
			if (truth) {

				//Nouvelle necessitée, style btn et montant correspondant
				$('#nM').removeClass('btn-warning glyphicon-pencil').addClass('btn-success glyphicon-share');
				$('#fourth').html('<input id="newFourthNecess" type="text" class="form-control" value="'+ $('#fourth').text() +'"/>');
				$('#fourth+td b').html('<input id="newFourthAmount" type="number" class="form-control" value="'+ $('#fourth+td b').text() +'"/>');

				truth = false;
			}
			else{
				//Nouvelle necessitée et montant nouvelle value
				$('#nM').removeClass('btn-success glyphicon-share').addClass('btn-warning glyphicon-pencil');
				$('#fourth').html($('#newFourthNecess').val());
				$('#fourth+td b').html($('#newFourthAmount').val());


				//After modifying of amount
				newCalc = new Calculation($('#first+td b').text(), $('#second+td b').text(), $('#third+td b').text(),$('#fourth+td b').text());
				newAccount = newCalc.calculate();
				newRest = aInitial.val() - newAccount;
				$('#total b').html(newAccount);
				$('#rest b').html(newRest);
				
				truth = true;
			}
		});
	}

	//Creating of delete function and useful variables
	function deleteBtn(){

		//First line
		$('#lS').on('click', ()=>{

			swal({
			  title: "Etes vous sûr?",
			  text: "Vous ne serai plus à mésure de retrouver les élements supprimés!",
			  type: "warning",
			  showCancelButton: true,
			  confirmButtonColor: "#DD6B55",
  			  cancelButtonText: "Non, annuler!",
			  confirmButtonText: "Oui, supprimer!",
			  closeOnConfirm: false,
			  closeOnCancel: false
			},
			function(isConfirm){
				if (isConfirm) 
				{
					$('#lS').parent().parent().remove();
			
					calculation.amount1 = 0;
					newAccount = calculation.calculate();
					newRest = aInitial.val() - newAccount;
					$('#total b').html(newAccount);
					$('#rest b').html(newRest);
					//Alert
					 swal("Supprimé!", "Suppression de la nécessité 'Loyer' éffectuée avec succès.", "success");
				}
				else
				{
					swal("Annulé!", "Suppression annulée avec succès", "error");
				}
			 
			});
			
			
		});	

		//Second line
		$('#eS').on('click', ()=>{
			
			swal({
			  title: "Etes vous sûr?",
			  text: "Vous ne serai plus à mésure de retrouver les élements supprimés!",
			  type: "warning",
			  showCancelButton: true,
			  confirmButtonColor: "#DD6B55",
			  confirmButtonText: "Oui, supprimer!",
			  cancelButtonText: "Non, annuler!",
			  closeOnConfirm: false,
			  closeOnCancel: false
			},
			function(isConfirm){
				if (isConfirm) 
				{
					$('#eS').parent().parent().remove();
			
					calculation.amount2 = 0;
					newAccount = calculation.calculate();
					newRest = aInitial.val() - newAccount;
					$('#total b').html(newAccount);
					$('#rest b').html(newRest);
					//Alert
					 swal("Supprimé!", "Suppression de la nécessité 'Electricité' éffectuée avec succès.", "success");
				}
				else
				{
					swal("Annulé!", "Suppression annulée avec succès", "error");
				}
			 
			});
		
		});

		//Third line
		$('#tS').on('click', ()=>{
			
			swal({
			  title: "Etes vous sûr?",
			  text: "Vous ne serai plus à mésure de retrouver les élements supprimés!",
			  type: "warning",
			  showCancelButton: true,
			  confirmButtonColor: "#DD6B55",
			  confirmButtonText: "Oui, supprimer!",
			  cancelButtonText: "Non, annuler!",
			  closeOnConfirm: false,
			  closeOnCancel: false
			},
			function(isConfirm){
				if (isConfirm) 
				{
					$('#tS').parent().parent().remove();
			
					calculation.amount3 = 0;
					newAccount = calculation.calculate();
					newRest = aInitial.val() - newAccount;
					$('#total b').html(newAccount);
					$('#rest b').html(newRest);
					//Alert
					 swal("Supprimé!", "Suppression de la nécessité 'Transport' éffectuée avec succès.", "success");
				}
				else
				{
					swal("Annulé!", "Suppression annulée avec succès", "error");
				}
			 
			});

			
		});

		//Fourth line
		$('#nS').on('click', ()=>{
			
			swal({
			  title: "Etes vous sûr?",
			  text: "Vous ne serai plus à mésure de retrouver les élements supprimés!",
			  type: "warning",
			  showCancelButton: true,
			  confirmButtonColor: "#DD6B55",
			  confirmButtonText: "Oui, supprimer!",
			  cancelButtonText: "Non, annuler!",
			  closeOnConfirm: false,
			  closeOnCancel: false
			},
			function(isConfirm){
				if (isConfirm) 
				{
					$('#nS').parent().parent().remove();
			
					calculation.amount4 = 0;
					newAccount = calculation.calculate();
					newRest = aInitial.val() - newAccount;
					$('#total b').html(newAccount);
					$('#rest b').html(newRest);
					//Alert
					 swal("Supprimé!", "Suppression de la nécessité 'Manger' éffectuée avec succès.", "success");
				}
				else
				{
					swal("Annulé!", "Suppression annulée avec succès", "error");
				}
			 
			});
			
		});
	}

	//Btn Réinitialiser
	function cancelAction(){
		$('#btnCancel').on('click', ()=>{
			//
			swal({
			  title: "Etes vous sûr?",
			  text: "Cette action permet de vider tous les élements du présent tableau!",
			  type: "warning",
			  showCancelButton: true,
			  confirmButtonColor: "#DD6B55",
			  confirmButtonText: "Oui, réinitialiser!",
			  cancelButtonText: "Non, annuler!",
			  closeOnConfirm: false,
			  closeOnCancel: false
			},
			function(isConfirm){
				if (isConfirm) 
				{
					
					//Alert
					 swal("Réinitialisé!", "Réinitialisation de tous les élements du tableau éffectuée avec succès.", "success");
					
					//
					$('tbody#tbodyNecess').empty();	
					$('#btn').empty();
				}
				else
				{
					swal("Annulé!", "Réinitialisation annulée avec succès", "error");
				}
			 
			});
		});
	}

	//Btn save 
	function saveAction(){
		//
		$('.btn-success').on('click', ()=>{
			//
			swal({
			  title: "Etre vous sure!",
			  text: "Cette action permet d'enregistrer tous les élements du présent tableau!",
			  type: "info",
			  showCancelButton: true,
			  closeOnConfirm: false,
			  showLoaderOnConfirm: true,
			},
			function(){
				  setTimeout(()=>{

				    swal("Opération terminée avec succès!");

				  }, 2000);
			});
			//Ajax
			var data = {
				initAmount : $('#initAmount').text(),
				necess1    : $('#first').text(),
				amount1    : $('#first+td b').text(),
				necess2    : $('#second').text(),
				amount2    : $('#second+td b').text(),
				necess3    : $('#third').text(),
				amount3    : $('#third+td b').text(),
				necess4    : $('#fourth').text(),
				amount4    : $('#fourth+td b').text(),
				total      : $('#total').text(),
				rest       : $('#rest').text()
			};
	
			var xhr = new XMLHttpRequest();
				xhr.open('GET', 'controller/management/controller.php?donnees='+JSON.stringify(data));
				//xhr.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
				xhr.send();
				xhr.onreadystatechange = ()=>{
					
					if(xhr.readyState == 4){
						$('body').append(xhr.responseText);
					}
					else{
						console.log('Ohh fu...');
					}
				};
	
		});
	}



});