<?php 
	session_start();

	if (isset($_GET['idArticle'])) {
		
		$_SESSION['idArticle'] = $_GET['idArticle'];
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<?php include ('view/partials/head.php')  ?>
	</head>
	<body>
		<?php include ('view/partials/header.php')  ?>
		<main>
			<?php include ('view/home_items/partials/update_content.php')  ?>
		</main>
	</body>
</html>