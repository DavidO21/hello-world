 <?php
 
//Inserting of request file
include_once('model/home_items/model.php');

//Definition of my object inside of my controller
$article = new Articles();

//Definition variales from post request
if (isset($_POST['article'],$_POST['montant'])) {
	
	//Send data
	$article->setArticle($_POST['article'], $_POST['montant']);
}

//Update action
if (isset($_POST['newArticle'],$_POST['newMontant'])) {

	$idArticle = $_SESSION['idArticle'];

	$article->updateArticle($idArticle, $_POST['newArticle'], $_POST['newMontant']);
}

//Delete action
if (isset($_GET['idArticle'])) {
	
	$id = $_GET['idArticle'];
	
	$article->deleteArtcle($id);
}


//Displaying of my data from db
$items =  $article->getArticle();


//Inserting of index file for my app starting
include_once('view/home_items/index.php');
